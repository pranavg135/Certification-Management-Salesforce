declare module "@salesforce/apex/FetchData.employeeData" {
  export default function employeeData(): Promise<any>;
}
declare module "@salesforce/apex/FetchData.certData" {
  export default function certData(): Promise<any>;
}
declare module "@salesforce/apex/FetchData.vouData" {
  export default function vouData(): Promise<any>;
}
declare module "@salesforce/apex/FetchData.reqData" {
  export default function reqData(): Promise<any>;
}
